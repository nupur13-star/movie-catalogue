package com.example.movie_catalogue.dto;

public record Genre(int id, String name) {
}
